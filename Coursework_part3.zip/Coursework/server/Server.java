import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.io.*;
import java.rmi.Remote;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.swing.Action;

import java.security.*;
import java.util.*;
import java.nio.*;

//implements Auction to do the srever
public class Server implements Auction {

    AuctionItem item1 = new AuctionItem();
    int userIDM = 0;
    int itemStart = 0;

    Map<Integer, String> Userhm = new HashMap<Integer, String>();
    Map<Integer, AuctionSaleItem> newAuctionhm = new HashMap<Integer, AuctionSaleItem>();
    Map<Integer, AuctionItem> itemhm = new HashMap<Integer, AuctionItem>();
    Map<Integer, Integer> UserItem = new HashMap<Integer, Integer>();

    AuctionItem AI = new AuctionItem();

    SecretKey key;

    public Server() {
        super();
        item1.itemID = 1;
        item1.description = "item1";
        item1.highestBid = 10000;
        item1.name = "item";

        // try {
        //     File file = new File("/home/jonesh19/h-drive/year 3/311/Coursework/keys/testKeys.aes");
        //     FileOutputStream Fos = new FileOutputStream(file);
        //     ObjectOutputStream Oos = new ObjectOutputStream(Fos);

        //     int m = 256;
        //     KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        //     keyGenerator.init(m);
        //     key = keyGenerator.generateKey();

        //     Oos.writeObject(key);
        //     Oos.close();

        // } catch (GeneralSecurityException e) {
        //     System.err.println(e);
        // } catch (IOException e) {
        // }

    }

    public Integer register(String email) {
        userIDM = userIDM + 1;
        int userID = userIDM;
        Userhm.put(userID, email);
        System.out.println("user id:  " + userID);
        System.out.println("email  " + email);
        System.out.println("hashmap  " + Userhm);
        return userID;
    }

    public AuctionItem getSpec(int ItemID) {
        if (ItemID > 0) {
            
            // if(ItemID == item1.itemID){
            System.out.println("Client request handled");
            AuctionSaleItem getSpecItem = newAuctionhm.get(ItemID);
            String itemName = getSpecItem.name;
            String itemDescription = getSpecItem.description;
            int itemBid = getSpecItem.reservePrice;
            AI.itemID = ItemID;
            AI.name = itemName;
            AI.description = itemDescription;
            AI.highestBid = itemBid;
            itemhm.put(ItemID, AI);
        } else {
            return null;
        }
        return AI;
    }

    public Integer newAuction(int userID, AuctionSaleItem item) {
        itemStart = itemStart + 1;
        System.out.println(itemStart);
        int itemID = itemStart;
        newAuctionhm.put(userID, item);
        System.out.println(newAuctionhm);
        UserItem.put(userID,itemID);
        return itemID;
    }

    public AuctionItem[] listItems(){
         for(int i = 0; i< itemStart; i++){
            AuctionSaleItem getSpecItem = newAuctionhm.get(i);
            String itemName = getSpecItem.name;
            String itemDescription = getSpecItem.description;
            int itemBid = getSpecItem.reservePrice;
            AI.itemID = i;
            AI.name = itemName;
            AI.description = itemDescription;
            AI.highestBid = itemBid;
            itemhm.put(i, AI);
      }
         return null;
     }

    public AuctionResult closeAuction(int userID, int itemID) {

        newAuctionhm.remove(userID);
        itemhm.remove(itemID);

        System.out.println(newAuctionhm + "   " + itemhm);

        AuctionResult result = new AuctionResult();
        result.winningEmail = Userhm.get(userID);
        result.winningPrice = 0;
        //use user id and item id get rid of the item 
        return result;
    }

    public boolean bid(int userID, int itemID, int price) {
        UserItem.get(userID);
        AuctionItem item = itemhm.get(itemID);
        int iPrice = item.highestBid;
        if (iPrice < price){
            item.highestBid = price;
            itemhm.replace(itemID, item);
            return true;
        }

        return false;
    }
    
    // main makes the server and readys it up
    public static void main(String[] args) {

        try {
            Server s = new Server();
            String name = "myserver";
            Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind(name, stub);
            System.out.println("Server ready");
        } catch (Exception e) {
            System.err.println("Exception:");
            e.printStackTrace();
        }
    }
}
