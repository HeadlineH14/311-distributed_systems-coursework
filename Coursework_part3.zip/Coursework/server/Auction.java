import java.rmi.RemoteException;
import java.rmi.Remote;


public interface Auction extends Remote {
 public Integer register(String email) throws RemoteException;
//save log in 
 public AuctionItem getSpec(int itemID) throws RemoteException;

 public Integer newAuction(int userID, AuctionSaleItem item) throws RemoteException;
 //create new auction
 public AuctionItem[] listItems() throws RemoteException;
 //list items in acuction
public AuctionResult closeAuction(int userID, int itemID) throws RemoteException;
//close the acution of an item 
public boolean bid(int userID, int itemID, int price) throws RemoteException;
//who is bidding on what 
}