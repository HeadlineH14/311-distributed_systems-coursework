import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;

import java.util.Scanner;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.KeyGenerator;
import java.nio.*;
import java.io.*;

//create clent class
public class Client{


//main for client takes argument in terminal, making sure its above 1
     public static void main(String[] args) {

      
      AuctionSaleItem ASI = new AuctionSaleItem();
      ASI.name = "item1";
      ASI.description = "test item";
      ASI.reservePrice = 1000;
      AuctionSaleItem ASI2 = new AuctionSaleItem();
      ASI2.name = "item2";
      ASI2.description = "test item2";
      ASI2.reservePrice = 10;

      int clientID = 0;
      int itemID = 0;

      int price = 0;
      
      
      while (true){
      if (args.length < 1) {
        //run loop for mor args
       System.out.println("Usage: java Client n");
       return;
      }

        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("What funtion do you want to use?");

        String input = myObj.nextLine();  // Read user input
        System.out.println("input is: " + input);  // Output user input
      // AuctionItem a = new AuctionItem();

         String n = args[0];
          try {
                    //gets server name and connects to it 
                        String name = "myserver";
                        Registry registry = LocateRegistry.getRegistry("localhost");
                        Auction server = (Auction) registry.lookup(name);

                        if (input.equals("register")){
                        clientID = server.register(n);
                        System.out.println(clientID);
                        }else if (input.equals("new auction")){
                          itemID = server.newAuction(clientID, ASI);
                          System.out.println("item1 = "+ itemID);




                        }else if(input.equals("getSpec")){
                          System.out.println("what item do you want the specs of");
                          String getSpecStr = myObj.nextLine();
                          int getSpecNum =0;
                          try{
                            getSpecNum= Integer.valueOf(getSpecStr);
                          }catch (NumberFormatException e){
                            System.out.println("invalid please enter an integer");
                          }

                        AuctionItem item = server.getSpec(getSpecNum);
                        int iID = item.itemID;
                        String iName = item.name;
                        String iDesc = item.description;
                        int iPrice = item.highestBid;
                        System.out.println("Item ID = "+iID);
                        System.out.println("Item name = "+iName);
                        System.out.println("Item description = "+iDesc);
                        System.out.println("Item highest bid = "+iPrice);
                        }else if(input.equals("itemlist")){
                          AuctionItem[] itemList = server.listItems();
                        System.out.println("list" + itemList);
                        }else if(input.equals("close")){
                          AuctionResult result = server.closeAuction(clientID, itemID);
                        }else if(input.equals("bid")){
                          System.out.println("what is the userid");
                          String bidUser = myObj.nextLine();
                          System.out.println("what is the itemid");
                          String bidItem = myObj.nextLine();
                          System.out.println("what is the new price");
                          String bidPrice = myObj.nextLine();
                          int bidprice =0;
                          int biduser = 0;
                          int biditem = 0;
                          try{
                            bidprice= Integer.valueOf(bidPrice);
                            biduser = Integer.valueOf(bidUser);
                            biditem = Integer.valueOf(bidItem);
                          }catch (NumberFormatException e){
                            System.out.println("invalid please enter an integer");
                          }
                          boolean bid = server.bid(biduser,biditem,bidprice);
                        }else break;
                          
                        }
                        catch (Exception e) {System.err.println("Exception:");e.printStackTrace();}
                      
                } 
}


     
//trys to connect to server
        
}
