cd Server
rmiregistry &
sleep 2
gnome-terminal -- java Server 1
gnome-terminal -- java Server 2
gnome-terminal -- java Server 3
java FrontEnd


