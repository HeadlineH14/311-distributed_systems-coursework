import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.io.*;
import java.rmi.Remote;
import javax.crypto.*;
import javax.crypto.spec.*;
import javax.swing.Action;

import java.io.FileOutputStream;
import java.security.*;
import java.util.*;
import java.nio.*;

//implements Auction to do the srever
public class Replica implements Auction {

    private String stubName;

    AuctionItem item1 = new AuctionItem();
    int userIDM = 0;
    int itemStart = 0;
    int ReplicaID;
    int MainReplicaID;


    Map<Integer, String> Userhm = new HashMap<Integer, String>();
    Map<Integer, AuctionSaleItem> newAuctionhm = new HashMap<Integer, AuctionSaleItem>();
    Map<Integer, AuctionItem> itemhm = new HashMap<Integer, AuctionItem>();
    Map<Integer, Integer> UserItem = new HashMap<Integer, Integer>();

    AuctionItem AI = new AuctionItem();


  

    public Replica(String StubName) {
        super();
        this.stubName = StubName;
        // ReplicaID = replicaID;
    }

    public Integer register(String email) {
        userIDM = userIDM + 1;
        int userID = userIDM;
        Userhm.put(userID, email);
        System.out.println("user id:  " + userID);
        System.out.println("email  " + email);
        System.out.println("hashmap  " + Userhm);
        return userID;
    }

    public AuctionItem getSpec(int ItemID) {
        if (ItemID > 0) {
            
            // if(ItemID == item1.itemID){
            System.out.println("Client request handled");
            AuctionSaleItem getSpecItem = newAuctionhm.get(ItemID);
            String itemName = getSpecItem.name;
            String itemDescription = getSpecItem.description;
            int itemBid = getSpecItem.reservePrice;
            AI.itemID = ItemID;
            AI.name = itemName;
            AI.description = itemDescription;
            AI.highestBid = itemBid;
            itemhm.put(ItemID, AI);
        } else {
            return null;
        }
        return AI;
    }

    public Integer newAuction(int userID, AuctionSaleItem item) {
        itemStart = itemStart + 1;
        System.out.println(itemStart);
        int itemID = itemStart;
        newAuctionhm.put(userID, item);
        System.out.println(newAuctionhm);
        UserItem.put(userID,itemID);
        return itemID;
    }

    public AuctionItem[] listItems(){
         for(int i = 0; i< itemStart; i++){
            AuctionSaleItem getSpecItem = newAuctionhm.get(i);
            String itemName = getSpecItem.name;
            String itemDescription = getSpecItem.description;
            int itemBid = getSpecItem.reservePrice;
            AI.itemID = i;
            AI.name = itemName;
            AI.description = itemDescription;
            AI.highestBid = itemBid;
            itemhm.put(i, AI);
      }
         return null;
     }

    public AuctionResult closeAuction(int userID, int itemID) {

        newAuctionhm.remove(userID);
        itemhm.remove(itemID);

        System.out.println(newAuctionhm + "   " + itemhm);

        AuctionResult result = new AuctionResult();
        result.winningEmail = Userhm.get(userID);
        result.winningPrice = 0;
        //use user id and item id get rid of the item 
        return result;
    }

    public boolean bid(int userID, int itemID, int price) {
        UserItem.get(userID);
        AuctionItem item = itemhm.get(itemID);
        int iPrice = item.highestBid;
        if (iPrice < price){
            item.highestBid = price;
            itemhm.replace(itemID, item);
            return true;
        }

        return false;
    }

    public int getPrimaryReplicaID(){
        return 1;
    }
    public int getReplicaID(){
        return ReplicaID;
    }
    public int updateMainReplica(int replicaID){
        MainReplicaID = replicaID;
        return MainReplicaID;
    }
    public void dummy()
  {
    System.out.println("");
  }


    // main makes the server and readys it up
     public static void main(String[] args) {
        

        if (args.length < 1) {
            //run loop for mor args
           System.out.println("Usage: java Server n");
          }else{
          

            try {
                String n = args[0];
                String name = "Auction"+n;
                Replica s = new Replica(name);
                System.out.println(s.stubName);
                int n2 = Integer.parseInt(n);
                // String name = s.stubName;
                
                Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
                Registry registry = LocateRegistry.getRegistry("localhost");
                registry.rebind(name, stub);
                System.out.println("Server ready");
            } catch (Exception e) {
                System.err.println("Exception:");
                e.printStackTrace();
            }
    }
  }
}
