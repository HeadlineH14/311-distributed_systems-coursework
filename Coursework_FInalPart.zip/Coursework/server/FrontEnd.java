import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.Remote;
import java.net.*;
import java.lang.*;
import java.util.*;


public class FrontEnd{


    int MainReplica = 0;
    int maxReplica = 1;
    public Server server;
    private ArrayList<Auction> servers;
    private Auction stub;
    Auction Auserver;

    public FrontEnd(){

    }

        /*
    // }
    public void UpdateReplicaRegister(String email){
        for(int i = 1; i<maxReplica;i++){
        s[i].register(email);
        System.err.println("register");
        }
    } 
    public void UpdateReplicagetSpec(int ItemID){
        for(int i = 1; i<maxReplica;i++){
        s[i].getSpec(ItemID);
        System.err.println("getSpec");
        }
    } 
    public void UpdateReplicanewAuction(int userid, AuctionSaleItem item){
        for(int i = 1; i<maxReplica;i++){
        s[i].newAuction(userid, item);
        System.err.println("newAuction");
        }
    } 
    public void UpdateReplicaAuctionItem(){
        for(int i = 1; i<maxReplica;i++){
        s[i].listItems();
        System.err.println("listItems");
        }
    } 
    public void UpdateReplicaCloseAuction(int userID, int itemID){
        for(int i = 1; i<maxReplica;i++){
        s[i].closeAuction(userID, itemID);
        System.err.println("closeauction");
        }
    } 
    public void UpdateReplicaBid(int userID, int itemID, int price){
        for(int i = 1; i<maxReplica;i++){
        s[i].bid(userID, itemID, price);
        System.err.println("Bid");
        }
    } 

        public Integer register(String email){
             int userID = s[MainReplica].register(email);
            // update the other servers before returnin the values
                UpdateReplicaRegister(email);
            return userID;
            //return null;

        }
        public AuctionItem getSpec(int itemID){
            AuctionItem AU = s[MainReplica].getSpec(itemID);
            return AU;
            // return null;
        }
        public Integer newAuction(int UserId, AuctionSaleItem item){
            int Item = s[MainReplica].newAuction(UserId,item);
            return Item;
            // return null;
        }
        public AuctionItem[] listItems(){
            return null;
        }
        public AuctionResult closeAuction(int userID,int itemID){
            AuctionResult result = s[MainReplica].closeAuction(userID, itemID);
            return result;
            // return null;
        }
        public boolean bid(int userID, int itemID, int price){
            boolean bid = s[MainReplica].bid(userID, itemID, price);
            return bid;
            // return true;
        }
        public int getPrimaryReplicaID(){
            //primary server should be s1 but if it goes down then need to make it so that it chagnes to the other servers and they will then be the main server 
            return MainReplica;
        }
 */
      public static void main(String[] args) throws Exception{
        
        int port = 20001;

          FrontEnd frontEnd = new FrontEnd();
          ServerSocket Wsoceket = new ServerSocket(17000);

          

          Socket connectionSocket = Wsoceket.accept();

          BufferedReader fromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));

          DataOutputStream toClient = new DataOutputStream(connectionSocket.getOutputStream());
            AuctionSaleItem a = new AuctionSaleItem();

          { 
              try{
                   
                    Registry registry = LocateRegistry.getRegistry("localhost");
                    frontEnd.Auserver = (Auction) registry.lookup("Auction");
                    registry.list();
                    
                  }catch(Exception e){
                      e.printStackTrace();
             }
          }

          while (true){

            String s = fromClient.readLine();
            int t = Integer.parseInt(s);

            switch (t) {
                case 0: s = fromClient.readLine();{
                
                System.out.println("register");
                int ans = frontEnd.Auserver.register(s);
                String ansConv = String.valueOf(ans);
                toClient.writeBytes(ansConv);
                System.out.println(ans);
                }
                case 1: 
                a.name = fromClient.readLine();
                a.description = fromClient.readLine();
                a.reservePrice = Integer.parseInt(fromClient.readLine());
                
                System.out.println(a.name + a.description + a.reservePrice);
                
                int ans1 = frontEnd.Auserver.newAuction(1,a);
                System.out.println("new auction");
                System.out.println(s);
                
                case 2: s = fromClient.readLine();
                int x = Integer.parseInt(s);
                AuctionItem au = frontEnd.Auserver.getSpec(x);
                System.out.println("getspec");
                System.out.println(s);
                
                case 3: s = fromClient.readLine();
                int o = Integer.parseInt(s);
                AuctionResult r = frontEnd.Auserver.closeAuction(1,o);
                System.out.println("close");
                System.out.println(s);
                
                case 4: s = fromClient.readLine();
                int uid = Integer.parseInt(fromClient.readLine());
                int iid = Integer.parseInt(fromClient.readLine());
                int p = Integer.parseInt(fromClient.readLine());
                frontEnd.Auserver.bid(uid,iid ,p);
                System.out.println("bid");
                System.out.println(s);

                case 5: s = fromClient.readLine();
                AuctionItem[] itemlist = frontEnd.Auserver.listItems();
                System.out.println("list");
                System.out.println(s);
                default:
                    break;
            }
            break;
          }
          /*

        //   int n = Integer.valueOf(n);
          
          int port = 2001;
        


        // for (int i = 0; i<n; i++){
        //     System.err.println(i);
        //     f.s[i] = new Server(i);
        //     System.err.println(f.s[i].getReplicaID());
        // }

        // if it calls for a fucntion then it can call it in main to get the server fucntion and return the result to the client 

        
        
         try {
             FrontEnd f = new FrontEnd(n);
             String name = "FrontEnd";
             Auction stub = (Auction) UnicastRemoteObject.exportObject(f, 0);
             Registry registry = LocateRegistry.getRegistry();
             registry.rebind(name, stub);
             System.out.println("Server ready");
         } catch (Exception e) {
             System.err.println("Exception:");
             e.printStackTrace();
         }

        //  for (int i = 0; i<n; i++){
        //     // String name = "Auction"+(i+1);
        //     // System.out.println(name);
        //     // Registry registryServer = null;
        //     try {
        //             Server s = new Server(i);
        //             String Newname = "Auction"+i;
        //            System.out.println(Newname);
        //             Auction stub = (Auction) UnicastRemoteObject.exportObject((Server)s,0);
        //             Registry registry = LocateRegistry.createRegistry(port);
        //             registry.rebind(Newname, stub);
        //             System.out.println("Server ready");
        //              System.out.println(Newname);
        //         } catch (Exception e) {
        //             System.err.println("Exception:");
        //             e.printStackTrace();
        //         }



        // //         port = port+1;  

        //   }





        //  Registry m = null;

        //  try {
        //     m = LocateRegistry.getRegistry("localhost");
        //     }
        //     catch (Exception e)
        //     {
        //     System.out.println("0:fail:RMI registry instance not found by LocateRegistry()");
        //     return;
        //     }

        // try to make a new instance of server and then connect use rmi in this class to seal teh object 
            // try {
            //     registryServer = LocateRegistry.getRegistry("localhost");
            //     }
            //     catch (Exception e)
            //     {
            //         System.err.println(e);
            //     System.out.println("0:fail:RMI registry instance not found by LocateRegistry()");
            //     return;
            //     }
            //     System.out.println(registryServer);
            //     try{
            //     f.s[i] = (Server) registryServer.lookup(name);
            //     }catch(Exception e){e.printStackTrace();
            //         System.out.println("1:fail:no RMI service found by the name: " + name);
            //         return;}
            //     try {
            
            //         int replicaID = f.s[i].getPrimaryReplicaID();
            //         System.out.println("2:pass:Auction interface matches specification");
                        
            //     }
            //         catch (Exception e) {
            //         System.out.println("2:fail – Auction interface does not match the specification");
            //         e.printStackTrace();
            //         return;
            //     }
                
            // System.err.println(f.s[i].getReplicaID());
            
            // port = port+1;*/
       
     }
    //  public static ArrayList<Auction> getServers(){
    //     ArrayList<Auction> serverlist = new ArrayList<Auction>();
    //     try{
    //         Registry registry = LocateRegistry.getRegistry("localhost",20001);
    //         for(String name : registry.list())
    //         {
    //             System.out.println(name);
    //             try{
    //                 Auction sStub = (Auction) registry.lookup(name);
    //                 serverlist.add(sStub);
    //             }catch (Exception e){
    //                  System.err.println("Client exception: " + e.toString());
    //                 e.printStackTrace();
    //             }
    //         }
    //     }catch (Exception e){
    //         e.printStackTrace();
    //     }
    //     return serverlist;
    //  }
   
    }