import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.net.Socket;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;

import java.util.Scanner;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.KeyGenerator;
import java.nio.*;
import java.io.*;

//create clent class
public class Client{


//main for client takes argument in terminal, making sure its above 1
     public static void main(String[] args) throws Exception{

      
      AuctionSaleItem ASI = new AuctionSaleItem();
      // ASI.name = "item1";
      // ASI.description = "test item";
      // ASI.reservePrice = 1000;
      // AuctionSaleItem ASI2 = new AuctionSaleItem();
      // ASI2.name = "item2";
      // ASI2.description = "test item2";
      // ASI2.reservePrice = 10;


      BufferedReader fromUser = new BufferedReader(new InputStreamReader(System.in));
      
      Socket clientSocket = new Socket("localhost", 17000);

      DataOutputStream toServer = new DataOutputStream(clientSocket.getOutputStream());

      BufferedReader fromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));


      int clientID = 0;
      int itemID = 0;

      int price = 0;
      
      int t;

      while (true){
      if (args.length < 1) {
        //run loop for mor args
       System.out.println("Usage: java Client n");
       return;
      }


      System.out.println("Please select a command");
      System.out.println("register 0");
      System.out.println("New Auction 1");
      System.out.println("getSpec 2");
      System.out.println("close 3");
      System.out.println("bid 4");
      System.out.println("list items 5");


      String s = fromUser.readLine();
      t = Integer.parseInt(s);

      if (t == 0||t == 1 || t == 2 || t == 3 || t == 4|| t == 5){
        toServer.writeBytes(t+"\n");
      }else{
        System.out.println("please input a valid option");
      }

      switch (t) {
        case 0: System.out.println("please enter an email");
          s = fromUser.readLine();
          System.out.println("email is "+ s);
          toServer.writeBytes(s +"\n");
         break;

        case 1: System.out.println("please enter the name of the Auction");
          String temp1 = fromUser.readLine();
          toServer.writeBytes(temp1);
          System.out.println("please enter the description of the Auction");
          String temp2 = fromUser.readLine();
          toServer.writeBytes(temp2);
          System.out.println("please enter the price of the Auction");
          String temp3  = fromUser.readLine();
          toServer.writeBytes(temp3);
          // try to write each part after its read
          break;

        case 2: System.out.println("what item do you want the spec of");
          s = fromUser.readLine();
          toServer.writeBytes(s+ "\n");
          break;

        case 3: System.out.println("what item auction would you like to close?");
          s = fromUser.readLine();
          toServer.writeBytes(s+ "\n");
          break;

        case 4: System.out.println("which item would you like to bid on?");
          s = fromUser.readLine();
          toServer.writeBytes(s);
          break;

        case 5: 
          s = "5";
          toServer.writeBytes(s);
          break;
      
        default: System.out.println("please slelct an operation");
          break;
      }



      /* 
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        System.out.println("What funtion do you want to use?");

        String input = myObj.nextLine();  // Read user input
        System.out.println("input is: " + input);  // Output user input
      // AuctionItem a = new AuctionItem();

         String n = args[0];
          try {
                    //gets server name and connects to it 
                    
                        String name = "Auction";
                        Registry registry = LocateRegistry.getRegistry("localhost");
                        Auction server = (Auction) registry.lookup(name);

                        if (input.equals("register")){
                        clientID = server.register(n);
                        System.out.println(clientID);
                        }else if (input.equals("new auction")){
                          itemID = server.newAuction(clientID, ASI);
                          System.out.println("item1 = "+ itemID);
                          
                      String name = "FrontEnd";
                      Registry registry = LocateRegistry.getRegistry("localhost");
                      Auction server = (Auction) registry.lookup(name);

                      //register
                      if (input.equals("0")){
                          clientID = server.register(n);
                          System.out.println("Client id = "+clientID);
                      // new auction
                      }else if (input.equals("1")){
                          itemID = server.newAuction(clientID, ASI);
                          System.out.println("item1 = "+ itemID);
                      // getSpec
                      }else if(input.equals("2")){
                          System.out.println("what item do you want the specs of");
                          String getSpecStr = myObj.nextLine();
                          int getSpecNum =0;
                          try{
                            getSpecNum= Integer.valueOf(getSpecStr);
                          }catch (NumberFormatException e){
                            System.out.println("invalid please enter an integer");
                          }

                        AuctionItem item = server.getSpec(getSpecNum);
                        int iID = item.itemID;
                        String iName = item.name;
                        String iDesc = item.description;
                        int iPrice = item.highestBid;
                        System.out.println("Item ID = "+iID);
                        System.out.println("Item name = "+iName);
                        System.out.println("Item description = "+iDesc);
                        System.out.println("Item highest bid = "+iPrice);
                        // item list
                        }else if(input.equals("5")){
                          AuctionItem[] itemList = server.listItems();
                        System.out.println("list" + itemList);
                        // close auction
                        }else if(input.equals("3")){
                          AuctionResult result = server.closeAuction(clientID, itemID);
                        // bid
                        }else if(input.equals("4")){
                          System.out.println("what is the userid");
                          String bidUser = myObj.nextLine();
                          System.out.println("what is the itemid");
                          String bidItem = myObj.nextLine();
                          System.out.println("what is the new price");
                          String bidPrice = myObj.nextLine();
                          int bidprice =0;
                          int biduser = 0;
                          int biditem = 0;
                          try{
                            bidprice= Integer.valueOf(bidPrice);
                            biduser = Integer.valueOf(bidUser);
                            biditem = Integer.valueOf(bidItem);
                          }catch (NumberFormatException e){
                            System.out.println("invalid please enter an integer");
                          }
                          boolean bid = server.bid(biduser,biditem,bidprice);
                        }else break;
                          
                        }
                        catch (Exception e) {System.err.println("Exception:");e.printStackTrace();}
                    */  
                } 
}


     
//trys to connect to server
        
}
