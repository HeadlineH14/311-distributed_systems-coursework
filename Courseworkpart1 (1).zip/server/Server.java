import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.io.*;
import java.rmi.Remote;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.security.*;
import java.util.*;
import java.nio.*;

//implements Auction to do the srever
public class Server implements Auction{
   
   AuctionItem item1 = new AuctionItem();
   
   
   SecretKey key;
   
    public Server() {
        super();
        item1.itemID = 1;
        item1.description = "item1";
        item1.highestBid = 10000;
        item1.name = "item";

      try{
         File file = new File("/home/jonesh19/h-drive/year 3/311/Coursework/keys/testKeys.aes");
         FileOutputStream Fos = new FileOutputStream(file);
         ObjectOutputStream Oos = new ObjectOutputStream(Fos);

        
         int m = 256;
         KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
         keyGenerator.init(m);
         key = keyGenerator.generateKey();



         Oos.writeObject(key);
         Oos.close();

      }catch (GeneralSecurityException e){System.err.println(e);}
      catch (IOException e){}

     }


   public SealedObject getSpec(int n){

      File SealedFile = new File("SealedObject.txt");
      try{

         
         //creates file and object output streams
         FileOutputStream FoutPutStream = new FileOutputStream(SealedFile,true);
         ObjectOutputStream OOutPutStream = new ObjectOutputStream(FoutPutStream);
         
         if (n == item1.itemID){
         Cipher c = Cipher.getInstance("AES");
         c.init(Cipher.ENCRYPT_MODE,key);
         SealedObject So = new SealedObject(item1,c);

         OOutPutStream.writeObject(So);
         OOutPutStream.reset();
         OOutPutStream.close();
         
         return So;
         }
      }catch (IOException e){System.err.println(e);}
      catch (GeneralSecurityException e){System.err.println(e);}
         return null;
   }

  //main makes the server and readys it up 
     public static void main(String[] args) {   

        try {
         Server s = new Server();
         String name = "myserver";
         Auction stub = (Auction) UnicastRemoteObject.exportObject(s, 0);
         Registry registry = LocateRegistry.getRegistry();
         registry.rebind(name, stub);
         System.out.println("Server ready");
        } catch (Exception e) {
         System.err.println("Exception:");
         e.printStackTrace();
        }
      }
  }
  