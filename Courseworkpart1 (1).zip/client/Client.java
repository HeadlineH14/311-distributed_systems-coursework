import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SealedObject;
import javax.crypto.SecretKey;
import javax.crypto.KeyGenerator;
import java.nio.*;
import java.io.*;

//create clent class
public class Client{



//main for client takes argument in terminal, making sure its above 1
     public static void main(String[] args) {
       if (args.length < 1) {
       System.out.println("Usage: java Client n");
       return;
       }

       AuctionItem a = new AuctionItem();

         int n = Integer.parseInt(args[0]);

         File testKey = new File("/home/jonesh19/h-drive/year 3/311/Coursework/keys/testKeys.aes");
//trys to connect to server
         try {
          //gets server name and connects to it 
               String name = "myserver";
               Registry registry = LocateRegistry.getRegistry("localhost");
               Auction server = (Auction) registry.lookup(name);


               // use file and object streams to get the data from sealed object 
              FileInputStream FipKey = new FileInputStream(testKey);
              ObjectInputStream OipKey = new ObjectInputStream(FipKey);

              SecretKey key = (SecretKey)OipKey.readObject();
              //get key from file 
              OipKey.close();

              Cipher c = Cipher.getInstance("AES");
              c.init(Cipher.DECRYPT_MODE, key);

              SealedObject encryptedObject = server.getSpec(n);
              

              try {
                a = (AuctionItem)encryptedObject.getObject(key);
              }catch(Exception e){}

              System.out.println("ItemID: "+a.itemID+ "\n" +"Item Description: "+ a.description + "\n" + "Item highest bid: " +a.highestBid + "\n" + "Item Name: " +a.name);
              
              
                 
              }
              catch (Exception e) {System.err.println("Exception:");e.printStackTrace();}
      }
}
