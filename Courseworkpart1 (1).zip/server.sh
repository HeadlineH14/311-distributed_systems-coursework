cd Server
rmiregistry &
sleep 2
java Server
